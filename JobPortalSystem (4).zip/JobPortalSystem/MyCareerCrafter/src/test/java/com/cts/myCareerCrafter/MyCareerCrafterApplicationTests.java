package com.cts.myCareerCrafter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyCareerCrafterApplicationTests {

	@Test
	void contextLoads() {
	}

}
