package com.cts.myCareerCrafter.controllertest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

import com.cts.myCareerCrafter.controller.CompanyProfileController;
import com.cts.myCareerCrafter.dto.CompanyProfileDTO;
import com.cts.myCareerCrafter.dto.CompanyProfilesResponseDTO;
import com.cts.myCareerCrafter.service.CompanyProfileService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;

public class CompanyProfileControllerTest {

    @Mock
    private CompanyProfileService companyProfileService;

    @InjectMocks
    private CompanyProfileController companyProfileController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateProfile() {
        CompanyProfileDTO dto = new CompanyProfileDTO();
        dto.setCompanyName("CTS");
        dto.setDomain("IT Industry");
        dto.setDescription("Information technology services and consulting company");
        dto.setLocation("Coimbatore");
        dto.setContact("8976493746");

        when(companyProfileService.createProfile(anyLong(), any(CompanyProfileDTO.class))).thenReturn(dto);

        ResponseEntity<CompanyProfileDTO> response = companyProfileController.createProfile(1L, dto);

        assertNotNull(response);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("CTS", response.getBody().getCompanyName());
    }

    @Test
    public void testGetAllProfiles() {
        CompanyProfilesResponseDTO responseDTO = new CompanyProfilesResponseDTO(1, Arrays.asList(new CompanyProfileDTO()));

        when(companyProfileService.getAllProfiles(anyLong())).thenReturn(responseDTO);

        ResponseEntity<CompanyProfilesResponseDTO> response = companyProfileController.getAllProfiles(1L);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().getCount());
    }

    @Test
    public void testGetProfileById() {
        CompanyProfileDTO dto = new CompanyProfileDTO();
        dto.setCompanyName("CTS");
        dto.setDomain("IT Industry");
        dto.setDescription("Information technology services and consulting company");
        dto.setLocation("Coimbatore");
        dto.setContact("8976493746");

        when(companyProfileService.getProfileById(anyLong(), anyLong())).thenReturn(dto);

        ResponseEntity<CompanyProfileDTO> response = companyProfileController.getProfileById(1L, 1L);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("CTS", response.getBody().getCompanyName());
    }

    @Test
    public void testUpdateProfile() {
        CompanyProfileDTO dto = new CompanyProfileDTO();
        dto.setCompanyName("CTS Updated");
        dto.setDomain("IT Industry Updated");
        dto.setDescription("Updated description");
        dto.setLocation("Updated location");
        dto.setContact("1234567890");

        when(companyProfileService.updateProfile(anyLong(), anyLong(), any(CompanyProfileDTO.class))).thenReturn(dto);

        ResponseEntity<CompanyProfileDTO> response = companyProfileController.updateProfile(1L, 1L, dto);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("CTS Updated", response.getBody().getCompanyName());
    }

    @Test
    public void testDeleteProfile() {
        doNothing().when(companyProfileService).deleteProfile(anyLong(), anyLong());

        ResponseEntity<Void> response = companyProfileController.deleteProfile(1L, 1L);

        assertNotNull(response);
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    }
}
