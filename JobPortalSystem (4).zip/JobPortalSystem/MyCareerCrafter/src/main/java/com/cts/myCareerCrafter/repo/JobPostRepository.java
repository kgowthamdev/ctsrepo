package com.cts.myCareerCrafter.repo;

import com.cts.myCareerCrafter.entity.JobPost;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface JobPostRepository extends JpaRepository<JobPost, Long> {
	List<JobPost> findByCompanyId(Long company_id);
    Optional<JobPost> findByIdAndCompanyId(Long job_id,Long company_id);
}
