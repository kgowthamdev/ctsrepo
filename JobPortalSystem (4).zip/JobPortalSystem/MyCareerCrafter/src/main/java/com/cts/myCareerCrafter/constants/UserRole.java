package com.cts.myCareerCrafter.constants;

public enum UserRole {
	USER,EMPLOYER
}
