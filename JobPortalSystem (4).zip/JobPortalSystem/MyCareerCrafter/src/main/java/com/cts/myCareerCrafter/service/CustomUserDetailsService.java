//package com.cts.myCareerCrafter.service;
//import com.cts.myCareerCrafter.config.CustomUserDetails;
//import com.cts.myCareerCrafter.entity.ApplicantUser;
//import com.cts.myCareerCrafter.entity.CompanyUser;
//import com.cts.myCareerCrafter.entity.Roles;
//import com.cts.myCareerCrafter.exception.UserException;
//import com.cts.myCareerCrafter.repo.ApplicantUserRepository;
//import com.cts.myCareerCrafter.repo.CompanyUserRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.stereotype.Service;
//import org.springframework.security.core.GrantedAuthority;
//import org.springframework.security.core.authority.SimpleGrantedAuthority;
//
//import java.util.Collection;
//import java.util.Set;
//import java.util.stream.Collectors;
//
//@Service
//public class CustomUserDetailsService implements UserDetailsService {
//
//    @Autowired
//    private ApplicantUserRepository applicantUserRepository;
//
//    @Autowired
//    private CompanyUserRepository companyUserRepository;
//
//    @Override
//    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
//        ApplicantUser applicantUser = applicantUserRepository.findByEmail(email);
//        if (applicantUser != null) {
//            return new CustomUserDetails(
//                applicantUser.getEmail(),
//                applicantUser.getPassword(),
//                getAuthorities(applicantUser.getRoles()),
//                applicantUser.getApplicantId()
//            );
//        }
//
//        CompanyUser companyUser = companyUserRepository.findByEmail(email);
//        if (companyUser != null) {
//            return new CustomUserDetails(
//                companyUser.getEmail(),
//                companyUser.getPassword(),
//                getAuthorities(companyUser.getRoles()),
//                companyUser.getCompanyId()
//            );
//        }
//
//        throw new UserException("User not found with email",HttpStatus.NOT_FOUND);
//    }
//
//    private Collection<? extends GrantedAuthority> getAuthorities(Set<Roles> roles) {
//        return roles.stream()
//            .map(role -> new SimpleGrantedAuthority("ROLE_" + role.getName().name()))
//            .collect(Collectors.toList());
//    }
//}