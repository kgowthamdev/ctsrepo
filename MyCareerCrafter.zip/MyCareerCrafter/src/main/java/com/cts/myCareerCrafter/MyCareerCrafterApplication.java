package com.cts.myCareerCrafter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyCareerCrafterApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyCareerCrafterApplication.class, args);
	}

}
