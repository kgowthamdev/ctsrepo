package com.cts.myCareerCrafter.constants;

public enum JobApplicationStatus {
    ACCEPTED, REJECTED, PENDING;
}
