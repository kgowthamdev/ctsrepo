package com.cts.myCareerCrafter.repo;

import com.cts.myCareerCrafter.entity.CompanyProfile;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CompanyProfileRepository extends JpaRepository<CompanyProfile, Long> {

    List<CompanyProfile> findByCompanyId(Long companyId);

    Optional<CompanyProfile> findByCompanyIdAndId(Long companyId, Long profileId);

	boolean existsByContact(String contact);
}

